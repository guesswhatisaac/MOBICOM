package com.mobdeve.s18.roman.isaacnathan.lifecycle_nongraded;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    // Define a name for our SharedPreferences file
    private static final String PREFS_NAME = "LifecycleCounterPrefs";

    private EditText
            onCreateField, onStartField, onResumeField,
            onPauseField, onStopField, onDestroyField;
    private int
            createVal, startVal, resumeVal,
            pauseVal, stopVal, destroyVal;

    private SharedPreferences prefs;

    //(1) onCreate is the function called when the activity is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG,"onCreate called");

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        this.onCreateField = findViewById(R.id.onCreateField);
        this.onStartField = findViewById(R.id.onStartField);
        this.onResumeField = findViewById(R.id.onResumeField);
        this.onPauseField = findViewById(R.id.onPauseField);
        this.onStopField = findViewById(R.id.onStopField);
        this.onDestroyField = findViewById(R.id.onDestroyField);

        if (savedInstanceState == null) {
            loadData();
        }

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });

        this.createVal++;
        onCreateField.setText(String.valueOf(this.createVal));
    }

    //(2) onStart is the function called when the activity is about to become visible.
    @Override
    protected void onStart(){
        super.onStart();
        Log.d(TAG, "onStart called");

        this.startVal++;
        onStartField.setText(String.valueOf(this.startVal));
    }

    //(3) onResume is the function called when the activity is going to resume
    //    from another activity.
    @Override
    protected void onResume(){
        super.onResume();
        Log.d(TAG, "onResume called");

        this.resumeVal++;
        onResumeField.setText(String.valueOf(this.resumeVal));
    }

    //(4) onPause is the function called when the activity is about to start
    //    another activity.
    @Override
    protected void onPause(){
        super.onPause();
        Log.d(TAG, "onPause called");

        this.pauseVal++;
        onPauseField.setText(String.valueOf(this.pauseVal));
    }

    //(5) onStop is the function called when the activity is no longer visible.
    //    This is a good place to save persistent data.
    @Override
    protected void onStop(){
        super.onStop();
        Log.d(TAG, "onStop called");

        this.stopVal++;
        onStopField.setText(String.valueOf(this.stopVal));

        saveData();
    }

    //(6) onDestroy is the function called when the activity is destroyed
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG,"onDestroy called");

        this.destroyVal++;
        onDestroyField.setText(String.valueOf(this.destroyVal));
    }

    //(7) onSaveInstanceState is still used to handle runtime configuration changes (like rotation).
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(TAG,"onSaveInstanceState called");

        outState.putInt(MyKeys.ON_CREATE_KEY.name(), this.createVal);
        outState.putInt(MyKeys.ON_START_KEY.name(), this.startVal);
        outState.putInt(MyKeys.ON_RESUME_KEY.name(), this.resumeVal);
        outState.putInt(MyKeys.ON_PAUSE_KEY.name(), this.pauseVal);
        outState.putInt(MyKeys.ON_STOP_KEY.name(), this.stopVal);
        outState.putInt(MyKeys.ON_DESTROY_KEY.name(), this.destroyVal);
    }

    //(8) onRestoreInstanceState restores the data after a configuration change.
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(TAG,"onRestoreInstanceState called");

        this.createVal = savedInstanceState.getInt(MyKeys.ON_CREATE_KEY.name());
        this.startVal = savedInstanceState.getInt(MyKeys.ON_START_KEY.name());
        this.resumeVal = savedInstanceState.getInt(MyKeys.ON_RESUME_KEY.name());
        this.pauseVal = savedInstanceState.getInt(MyKeys.ON_PAUSE_KEY.name());
        this.stopVal = savedInstanceState.getInt(MyKeys.ON_STOP_KEY.name());
        this.destroyVal = savedInstanceState.getInt(MyKeys.ON_DESTROY_KEY.name());

        updateAllFields();
    }

    /**
     * Loads the lifecycle counts from SharedPreferences.
     */
    private void loadData() {
        Log.d(TAG, "Loading data from SharedPreferences.");
        // For each key, retrieve the saved value. If not found, default to 0.
        this.createVal = prefs.getInt(MyKeys.ON_CREATE_KEY.name(), 0);
        this.startVal = prefs.getInt(MyKeys.ON_START_KEY.name(), 0);
        this.resumeVal = prefs.getInt(MyKeys.ON_RESUME_KEY.name(), 0);
        this.pauseVal = prefs.getInt(MyKeys.ON_PAUSE_KEY.name(), 0);
        this.stopVal = prefs.getInt(MyKeys.ON_STOP_KEY.name(), 0);
        this.destroyVal = prefs.getInt(MyKeys.ON_DESTROY_KEY.name(), 0);
        updateAllFields();
    }

    /**
     * Saves the current lifecycle counts to SharedPreferences.
     */
    private void saveData() {
        Log.d(TAG, "Saving data to SharedPreferences.");
        SharedPreferences.Editor editor = prefs.edit();

        editor.putInt(MyKeys.ON_CREATE_KEY.name(), this.createVal);
        editor.putInt(MyKeys.ON_START_KEY.name(), this.startVal);
        editor.putInt(MyKeys.ON_RESUME_KEY.name(), this.resumeVal);
        editor.putInt(MyKeys.ON_PAUSE_KEY.name(), this.pauseVal);
        editor.putInt(MyKeys.ON_STOP_KEY.name(), this.stopVal);
        editor.putInt(MyKeys.ON_DESTROY_KEY.name(), this.destroyVal);

        editor.apply();
    }

    /**
     * Helper method to update all EditText fields with the current variable values.
     */
    private void updateAllFields() {
        this.onCreateField.setText(String.valueOf(this.createVal));
        this.onStartField.setText(String.valueOf(this.startVal));
        this.onResumeField.setText(String.valueOf(this.resumeVal));
        this.onPauseField.setText(String.valueOf(this.pauseVal));
        this.onStopField.setText(String.valueOf(this.stopVal));
        this.onDestroyField.setText(String.valueOf(this.destroyVal));
    }
}