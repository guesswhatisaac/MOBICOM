package com.mobdeve.s18.roman.isaacnathan.lifecycle_nongraded;

public enum MyKeys {
    ON_CREATE_KEY,
    ON_START_KEY,
    ON_RESUME_KEY,
    ON_PAUSE_KEY,
    ON_STOP_KEY,
    ON_DESTROY_KEY
}
