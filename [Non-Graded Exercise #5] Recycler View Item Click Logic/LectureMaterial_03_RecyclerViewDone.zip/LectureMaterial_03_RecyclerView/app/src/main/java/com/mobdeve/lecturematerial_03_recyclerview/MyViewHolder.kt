package com.mobdeve.lecturematerial_03_recyclerview

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView.ViewHolder

/*  This is our custom ViewHolder class. Please note that the primary constructor of RecyclerView's
    ViewHolder requires an itemView to be passed (think of this as a super class constructor call).
    So we need to make sure we access that too. This class is usually instantiated in the
    onCreateViewHolder of the Adapter.
* */

class MyViewHolder(itemView: View): ViewHolder(itemView) {
    // In our item layout, we need two references -- an ImageView and a TextView. Please note that
    // the itemView is the RecyclerView -- which has context that we can use to find View instances.
    private val iv: ImageView = itemView.findViewById(R.id.characterImageIv)
    private val tv: TextView = itemView.findViewById(R.id.characterNameTv)

    // Variable to hold the current character bound to this ViewHolder
    private lateinit var currentCharacter: Character

    init {
        // Set the click listener for the entire item view
        itemView.setOnClickListener {
            if (::currentCharacter.isInitialized) {
                Toast.makeText(
                    itemView.context,
                    "Clicked: ${currentCharacter.name}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // This is our own method that accepts a Character object and sets our views' info accordingly.
    fun bindData(character: Character) {
        this.currentCharacter = character // Store the character for access in the click listener
        iv.setImageResource(character.imageId)
        tv.text = character.name
    }
}