package com.mobdeve.yourname.exercise3lifecyclesp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    // Data for the application
    private lateinit var data: ArrayList<PostModel>

    // RecyclerView components
    private lateinit var recyclerView: RecyclerView
    private lateinit var myAdapter: MyAdapter

    // Indicators for what Layout should be used or if the like buttons should be hidden
    private val recyclerViewDefaultView = LayoutType.LINEAR_VIEW_TYPE.ordinal // int of LayoutType.LINEAR_VIEW_TYPE (default) or LayoutType.GRID_VIEW_TYPE
    private val hideLikeButtons = false // true = hide buttons; false = shown buttons (default)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val isLinearView = sharedPrefs.getBoolean("isLinearView", true)
        val showLikes = sharedPrefs.getBoolean("showLikes", true)
        val viewType = if (isLinearView) LayoutType.LINEAR_VIEW_TYPE.ordinal else LayoutType.GRID_VIEW_TYPE.ordinal

        this.data = DataHelper.initializeData()
        this.recyclerView = findViewById(R.id.recyclerView)
        this.myAdapter = MyAdapter(this.data)

        this.recyclerView.layoutManager = getLayoutManager(viewType)
        this.myAdapter.setViewType(viewType)
        this.myAdapter.setHideLikeBtn(!showLikes)

        this.recyclerView.adapter = this.myAdapter
    }

    override fun onResume() {
        super.onResume()
        val sharedPrefs = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val isLinearView = sharedPrefs.getBoolean("isLinearView", true)
        val showLikes = sharedPrefs.getBoolean("showLikes", true)

        val newViewType = if (isLinearView) LayoutType.LINEAR_VIEW_TYPE.ordinal else LayoutType.GRID_VIEW_TYPE.ordinal

        recyclerView.layoutManager = getLayoutManager(newViewType)
        myAdapter.setViewType(newViewType)
        myAdapter.setHideLikeBtn(!showLikes)
        myAdapter.notifyDataSetChanged()
    }

    /*
     * Just a method to return a specific LayoutManager based on the ViewType provided.
     * */
    private fun getLayoutManager(value: Int): RecyclerView.LayoutManager {
        if (value == LayoutType.LINEAR_VIEW_TYPE.ordinal)
            return LinearLayoutManager(this)
        else
            return GridLayoutManager(this, 2)
    }

    /*
    * Responsible for inflating the options menu on the upper right corner of the screen.
    * */
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    /*
     * A little overkill tbh, but this method is responsible for handling the selection of items
     * in the options menu. There's only one item anyway -- Settings, which leads the user to the
     * Settings activity.
     * */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                val i = Intent(this@MainActivity, SettingsActivity::class.java)
                startActivity(i)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}