package com.mobdeve.yourname.exercise3lifecyclesp

import android.content.Context
import android.os.Bundle
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit

class SettingsActivity : AppCompatActivity() {

    private lateinit var linearViewSwitch: Switch
    private lateinit var hideLikeSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        this.linearViewSwitch = findViewById(R.id.viewSwitch)
        this.hideLikeSwitch = findViewById(R.id.hideLikeSwitch)

        val sharedPrefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val isLinearView = sharedPrefs.getBoolean("isLinearView", true)
        val showLikes = sharedPrefs.getBoolean("showLikes", true)

        linearViewSwitch.isChecked = isLinearView
        hideLikeSwitch.isChecked = !showLikes
    }

    override fun onPause() {
        super.onPause()
        val sharedPrefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        sharedPrefs.edit {
            putBoolean("isLinearView", linearViewSwitch.isChecked)
            putBoolean("showLikes", !hideLikeSwitch.isChecked)
        }
    }

}
