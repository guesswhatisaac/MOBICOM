package com.mobdeve.s18.roman.isaacnathan.exercise4processmanagement;

public enum Structures {
    PIGMAN,
    MERMAN,
    MUSHROOM,
    DAPPER,
    TOTALLY_NORMAL
}
