package com.mobdeve.s18.roman.isaacnathan.fakeadex

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SnapHelper


class MainActivity : AppCompatActivity() {

    private lateinit var dexRecyclerView: RecyclerView
    private lateinit var dexAdapter: DexAdapter
    private lateinit var dexList: ArrayList<PokemonModel>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        // 1. Get Data
        dexList = DataGenerator.loadData()

        // 2. Find RecyclerView
        dexRecyclerView = findViewById(R.id.recyclerView)


        // 3. Create Adapter Instance
        dexAdapter = DexAdapter(dexList)

        // 4. Set Adapter
        dexRecyclerView.adapter = dexAdapter

        // 5. Set LayoutManager
        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        dexRecyclerView.layoutManager = layoutManager
        val helper: SnapHelper = LinearSnapHelper()
        helper.attachToRecyclerView(dexRecyclerView)
        //dexRecyclerView.layoutManager = LinearLayoutManager(this)

        //dexRecyclerView.setHasFixedSize(true)

    }
}