package com.mobdeve.s18.roman.isaacnathan.fakeadex

import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DexViewHolder(
    itemView: View,
    private val onDeleteClicked: (position: Int) -> Unit
) : RecyclerView.ViewHolder(itemView) {

    private val imageIv: ImageView = itemView.findViewById(R.id.image_iv)
    private val nameTv: TextView = itemView.findViewById(R.id.name_tv)
    private val descTv: TextView = itemView.findViewById(R.id.desc_tv)

    private val speciesDescTv: TextView = itemView.findViewById(R.id.species_value_tv)
    private val locationDescTv: TextView = itemView.findViewById(R.id.location_value_tv)
    private val deleteButton: Button = itemView.findViewById(R.id.button)

    fun bind(pokemon: PokemonModel) {
        imageIv.setImageResource(pokemon.imageId)
        nameTv.text = pokemon.name
        descTv.text = pokemon.desc
        speciesDescTv.text = pokemon.specie
        locationDescTv.text = pokemon.location
        // The listener is set in the init block
    }

    init {
        deleteButton.setOnClickListener {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                onDeleteClicked(position)
            }
        }
    }
}