package com.mobdeve.s18.roman.isaacnathan.fakeadex

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView



class DexAdapter(private val pokemons: ArrayList<PokemonModel>) : RecyclerView.Adapter<DexViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DexViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.pokedex, parent, false)
        return DexViewHolder(view) { position -> removeItem(position, parent.context) }

    }

    override fun onBindViewHolder(holder: DexViewHolder, position: Int) {
        val currPokemon: PokemonModel = pokemons[position]
        holder.bind(currPokemon)
    }

    override fun getItemCount(): Int {
        return pokemons.size
    }


    private fun removeItem(position: Int, context: android.content.Context) {
        if (position >= 0 && position < pokemons.size) {
            val deletedPokemonName = pokemons[position].name
            pokemons.removeAt(position)
            Toast.makeText(context, "$deletedPokemonName has been deleted.", Toast.LENGTH_SHORT).show()
            notifyItemRemoved(position)

        }
    }
}